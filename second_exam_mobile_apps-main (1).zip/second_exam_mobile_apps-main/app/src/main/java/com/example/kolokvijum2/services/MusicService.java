package com.example.kolokvijum2.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import com.example.kolokvijum2.MainActivity;
import com.example.kolokvijum2.R;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class MusicService extends Service {
    // MediaPlayer objekat koji nam omogucava reprodukovanje muzike i video zapisa,
    private MediaPlayer mediaPlayer;
    // Jedinstveni identifikatori za kanal notifikacija (koristi se od neke verzije) i samu notifikaciju,
    public static final String CHANNEL_ID = "MusicServiceChannel";
    public static final int NOTIFICATION_ID = 1;
    public static final String ACTION_PLAY_PAUSE = "ACTION_PLAY_PAUSE";
    private boolean isPlaying = false;
    public MusicService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // kada se sam servis napravi kreiramo notifikacioni kanal,
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

//        // kreiramo novu notifikaciju
//        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
//                .setContentTitle("Music Service")
//                .setContentText("Playing a random melody...")
//                .setSmallIcon(R.drawable.ic_launcher_foreground)
//                .build();
//
//        // pokrecemo nasu notifikaciju kao foreground servis i dajemo do znanja da je u pitanju
//        // prioritetan proces
//        startForeground(NOTIFICATION_ID, notification);
//
//        if (mediaPlayer != null) {
//            mediaPlayer.stop();
//            mediaPlayer.release();
//        }
//
//        mediaPlayer = MediaPlayer.create(this, R.raw.notification);
//        mediaPlayer.setLooping(true);
//        mediaPlayer.start();

        String action = intent.getAction();

        if (action != null && action.equals(ACTION_PLAY_PAUSE)) {
            // upravljaj play/pause toggle-om iz notifikacije
            togglePlayPause();
        } else {
           // inicijalna komanda
            startMusicAndForeground();
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            // oslobadja sve resurse koje je mediaplayer objekat koristio za izvrsavanje,
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_ID,
                "Music Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(serviceChannel);
    }

    private void startMusicAndForeground() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.notification);
            mediaPlayer.setLooping(true);
        }

        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
            isPlaying = true;
        }

        startForeground(NOTIFICATION_ID, buildNotification());
    }


    private void togglePlayPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                isPlaying = false;
            } else {
                mediaPlayer.start();
                isPlaying = true;
            }
            updateNotification();
        }
    }

    private Notification buildNotification() {

        // napravi intent
        Intent playPauseIntent = new Intent(this, MusicService.class);
        playPauseIntent.setAction(ACTION_PLAY_PAUSE);

        // pending intent nam omogucava da kreiramo intent i da omogucimo da ceka na izvrsavanje
        // od strane nekog drugog modula,
        PendingIntent pendingPlayPauseIntent =
                PendingIntent.getService(this,
                        0,
                        playPauseIntent,
                        PendingIntent.FLAG_IMMUTABLE);

        // biramo koju ikonicu zelimo da prikazemo u zavisnosti od flag-a
        int playPauseIcon;
        String playPauseText;
        if (isPlaying) {
            playPauseIcon = android.R.drawable.ic_media_pause;
            playPauseText = "Pause";
        } else {
            playPauseIcon = android.R.drawable.ic_media_play;
            playPauseText = "Play";
        }

        // notifikacija na koju moze da se klikne
        Intent activityIntent = new Intent(this, MainActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );


        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Music Service")
                .setContentText("test")
                .setContentIntent(contentIntent)
                .addAction(playPauseIcon, playPauseText, pendingPlayPauseIntent)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setShowActionsInCompactView(0))
                .setAutoCancel(true)
                .build();
    }

    private void updateNotification() {
        Notification notification = buildNotification();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, notification);
    }
}