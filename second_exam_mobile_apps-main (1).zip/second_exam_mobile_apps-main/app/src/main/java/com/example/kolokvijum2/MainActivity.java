package com.example.kolokvijum2;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.kolokvijum2.models.Product;
import com.example.kolokvijum2.services.MusicService;
import com.example.kolokvijum2.services.SwitchService;
import com.example.kolokvijum2.utils.ClientUtils;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private CheckBox musicCheckbox;
    private Button button;
    private SwitchCompat switchState;

    private final ActivityResultLauncher<String[]> multiplePermissionLauncher =
    registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
        result.forEach((permission, isGranted) -> {
            if (isGranted) {
                if (permission.equals(Manifest.permission.POST_NOTIFICATIONS)) {
                    PackageManager pm = this.getPackageManager();
                }
            } else {
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                    Toast.makeText(this, "Don't ask again: " + permission, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission denied: " + permission, Toast.LENGTH_SHORT).show();
                }
            }
        });
    });

    private final BroadcastReceiver colorReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("MainActivity", "onReceive was CALLED! Action: " + intent.getAction());

            if (intent != null && SwitchService.ACTION_UPDATE_COLOR.equals(intent.getAction())) {

                int backgroundColor = intent.getIntExtra(SwitchService.EXTRA_COLOR, Color.TRANSPARENT);

                Log.d("MainActivity", "Action matched! Setting color value: " + backgroundColor);
                updateBackgroundColor(backgroundColor);
            }
        }
    };


    @Override
    protected void onResume() {
        super.onResume();

        IntentFilter filter = new IntentFilter(SwitchService.ACTION_UPDATE_COLOR);

        Log.d("MainActivity", "--> ON_RESUME: Registering receiver for action: [" + SwitchService.ACTION_UPDATE_COLOR + "]");

        registerReceiver(colorReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.d("MainActivity", "--> ON_PAUSE: Unregistering receiver.");

        unregisterReceiver(colorReceiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // nalazimo checkbox i stavljamo event listener na checkiranje
        musicCheckbox = findViewById(R.id.musicCheckbox);
        musicCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // ukoliko je cekiran pokrece musicService
                startMusicService();
            } else {
                // ukoliko nije cekiran stopira ga
                stopMusicService();
            }
        });

        button = findViewById(R.id.serviceButton);
        button.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                startCheckingService();
            } else {
                multiplePermissionLauncher.launch(
                        new String[] {Manifest.permission.POST_NOTIFICATIONS}
                );
            }
        });

        ClientUtils.productClient.getAll().enqueue(new Callback<ArrayList<Product>>() {
            @Override
            public void onResponse(Call<ArrayList<Product>> call, Response<ArrayList<Product>> response) {
                if (response.isSuccessful()) {
                    Log.i("RESPONSETAG", response.body().get(0).getId().toString());
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Product>> call, Throwable t) {
                Log.d("RESPONSETAG", t.getMessage());
            }
        });

        switchState = findViewById(R.id.state_switch);
        loadSwitchState();
        switchState.setOnCheckedChangeListener((buttonView, isChecked) -> saveSwitchState(isChecked));
    }

    private void saveSwitchState(boolean isChecked) {
        SharedPreferences sharedPreferences = getSharedPreferences(SwitchService.SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SwitchService.SWITCH_STATE, isChecked);
        editor.apply();
    }
    private void loadSwitchState() {
        SharedPreferences sharedPreferences = getSharedPreferences(SwitchService.SHARED_PREFS, MODE_PRIVATE);
        boolean savedState = sharedPreferences.getBoolean(SwitchService.SWITCH_STATE, false);
        switchState.setChecked(savedState);
    }

    private void startCheckingService() {
        Intent serviceIntent = new Intent(this, SwitchService.class);
        // Use ContextCompat to handle different Android versions correctly
        ContextCompat.startForegroundService(this, serviceIntent);
        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show();
    }

    // s obzirom da se servisi pokrecu preko servisne namere kao sto je prikazano u ove dve metode
    private void startMusicService() {
        Intent serviceIntent = new Intent(this, MusicService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private void stopMusicService() {
        Intent serviceIntent = new Intent(this, MusicService.class);
        stopService(serviceIntent);
    }

    public void updateBackgroundColor(int color) {
        LinearLayout mainLayout = findViewById(R.id.main);
        mainLayout.setBackgroundColor(color);
    }
}