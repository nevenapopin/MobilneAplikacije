package com.example.kolokvijum2.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.IBinder;
import android.os.Handler;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.kolokvijum2.R;


public class SwitchService extends Service {
    // Tag koji ce se koristiti od strane logcat-a za tipiziranje logova,
    private static final String TAG = "CheckStatusService";
    // definisemo vremenski interval na koji ce se proveriti stanje switch-a
    private static final long CHECK_INTERVAL = 5 * 1000;
    // konstante shared preferences storage-a, osigurava da ne unesemo netacnu vrednost
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String SWITCH_STATE = "switchState";

    // Handler jer alat koji nam omogucav da definisemo neko vreme u kom ce se nas
    // kod izvrsiti
    private final Handler handler = new Handler();
    // Runnable predstavlja komponentu koja ce se izvrsiti, ovde definisemo nas task u ovom
    // slucaju proveravanje stanja switch-a
    private Runnable periodicCheck;
    public static final String ACTION_UPDATE_COLOR = "com.example.kolokvijum2.UPDATE_COLOR";
    public static final String EXTRA_COLOR = "com.example.kolokvijum2.EXTRA_COLOR";
    public SwitchService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "SERVICE IS BEING CREATED (onCreate)."); // LOG 2

        periodicCheck = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "TIMER FIRED. Running checkSwitchState()..."); // LOG 3

                checkSwitchState();

                // definisemo handler koji ce da pokrene runnable u kom se nalazimo,
                // nakon odredjenog vremena,
                handler.postDelayed(this, CHECK_INTERVAL);
            }
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "SERVICE HAS STARTED (onStartCommand). Starting handler."); // LOG 1

        promoteToForeground();
        handler.post(periodicCheck);
        return START_STICKY;
    }
    private void promoteToForeground() {
        final String CHANNEL_ID = "ForegroundServiceChannel";

        // --- THIS IS THE FIX ---
        // Notification Channels are only required for Android 8.0 (Oreo, API 26) and above.
        // This check prevents the app from crashing on older versions.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }

        // This part of the code works on all versions (thanks to NotificationCompat)
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Status Checker Service")
                .setContentText("Checking switch status every minute.")
                .setSmallIcon(R.mipmap.ic_launcher) // Make sure this icon exists!
                .build();

        startForeground(1, notification);
    }
    private void checkSwitchState() {
        Log.d(TAG, "Inside checkSwitchState()..."); // LOG 4

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        boolean isSwitchOn = sharedPreferences.getBoolean(SWITCH_STATE, false);
        Log.d(TAG, "Checking status... Switch is: " + (isSwitchOn ? "ON" : "OFF"));
        Intent intent = new Intent(ACTION_UPDATE_COLOR);

        if (isSwitchOn) {
            intent.putExtra(EXTRA_COLOR, Color.BLUE);
        } else {
            final String CHANNEL_ID = "ForegroundServiceChannel";

            intent.putExtra(EXTRA_COLOR, Color.WHITE);

            // --- THIS IS THE FIX ---
            // Notification Channels are only required for Android 8.0 (Oreo, API 26) and above.
            // This check prevents the app from crashing on older versions.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                NotificationChannel serviceChannel = new NotificationChannel(
                        CHANNEL_ID,
                        "Foreground Service Channel",
                        NotificationManager.IMPORTANCE_DEFAULT
                );
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) {
                    manager.createNotificationChannel(serviceChannel);
                }
            }

            // This part of the code works on all versions (thanks to NotificationCompat)
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Status Checker Service")
                    .setContentText("Ne valja")
                    .setSmallIcon(R.mipmap.ic_launcher) // Make sure this icon exists!
                    .build();

            startForeground(1, notification);
        }

        Log.d(TAG, "--> SENDING BROADCAST for action: " + intent.getAction()); // LOG 5
        intent.setPackage(getPackageName());

        sendBroadcast(intent);
        Log.d(TAG, "--> BROADCAST SENT.");

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }
}