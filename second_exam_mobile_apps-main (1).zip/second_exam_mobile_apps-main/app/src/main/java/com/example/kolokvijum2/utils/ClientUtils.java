package com.example.kolokvijum2.utils;

import com.example.kolokvijum2.client.ProductClient;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ClientUtils {
    // Url naseg backend API-ja, koji se cuva konstanta
    public static final String SERVICE_API_PATH = "http://10.0.2.2:8080/api/";

    public static OkHttpClient test(){
        // Interceptor koji je zaduzen da presretne svaki zahtev/ odgovor napravljen od strane OkHttpClient-a kako
        // bi cuvao njegove detalje
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();

        // Postavljamo tip detalja zahteva i odgovora koje zelimo da cuvamo u ovom slucaju je to Level.BODY kojim
        // imamo u vidu podatke o zaglavju i telu samog zahteva,
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        // Instanciramo OkHttpClient objekat i podesavamo vremenski limit nakong kog ce biti connection time out,
        // limit za cekanje odgovora, limit za slanje odgovora i sam interceptor koji smo prethodno definisali,
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(120, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .addInterceptor(interceptor).build();

        return client;
    }



    public static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(SERVICE_API_PATH)
            .addConverterFactory(GsonConverterFactory.create())
            .client(test())
            .build();

    public static ProductClient productClient = retrofit.create(ProductClient.class);
}