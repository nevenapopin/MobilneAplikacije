package fragments;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kolokvijum1.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import adapters.NotesAdapter;
import models.Note;
import repository.SQLiteHelper;
import com.example.kolokvijum1.AddNoteActivity;

public class BeleskeFragment extends Fragment {

    private static final int REQUEST_STORAGE_PERMISSION = 100;

    private RecyclerView rvNotes;
    private Button btnAddNote, btnFilterDate;
    private SQLiteHelper dbHelper;
    private int userId;
    private boolean isFiltered = false;

    private NotesAdapter adapter;
    private ArrayList<Note> notesList = new ArrayList<>();

    public BeleskeFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_beleske, container, false);

        rvNotes = view.findViewById(R.id.rvNotes);
        btnAddNote = view.findViewById(R.id.btnAddNote);
        btnFilterDate = view.findViewById(R.id.btnFilterDate);

        dbHelper = new SQLiteHelper(getContext());

        if (getArguments() != null) {
            userId = getArguments().getInt("userId", -1);
        }

        if (userId == -1) {
            Toast.makeText(getContext(), "Greška: korisnik nije ulogovan!", Toast.LENGTH_SHORT).show();
            return view;
        }

        rvNotes.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new NotesAdapter(notesList);
        rvNotes.setAdapter(adapter);

        loadNotes(false);  // učitava sve beleške

        btnFilterDate.setOnClickListener(v -> {
            if (isFiltered) {
                loadNotes(false);
                btnFilterDate.setText("Filtriraj po datumu");
                isFiltered = false;
            } else {
                loadNotes(true);
                btnFilterDate.setText("Prikaži sve beleške");
                isFiltered = true;
            }
        });

        btnAddNote.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_STORAGE_PERMISSION
                );
            } else {
                openAddNoteActivity();
            }
        });

        return view;
    }

    private void loadNotes(boolean filterToday) {
        notesList.clear();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        if (filterToday) {
            notesList.addAll(dbHelper.getNotesForUserTodayList(userId, today));
        } else {
            notesList.addAll(dbHelper.getNotesForUserList(userId));
        }

        adapter.notifyDataSetChanged();
    }

    private void openAddNoteActivity() {
        Intent intent = new Intent(getContext(), AddNoteActivity.class);
        intent.putExtra("userId", userId);  // šaljemo ID korisnika
        startActivity(intent);
    }

    private void showPermissionDeniedDialog() {
        new AlertDialog.Builder(getContext())
                .setTitle("Pristup odbijen")
                .setMessage("Pristup skladištu nije dozvoljen!")
                .setPositiveButton("U redu", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openAddNoteActivity();
            } else {
                showPermissionDeniedDialog();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadNotes(isFiltered); // Osvježi listu kad se fragment vrati u fokus
    }
}
