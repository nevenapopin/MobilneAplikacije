package repository;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import models.User;
import models.Note;
import utils.DatabaseConstants;
public class SQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "kolokvijum1.db";
    private static final int DATABASE_VERSION = 1;

    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public SQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    // Kreiranje tabela i inicijalni podaci
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tabela korisnika
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "fullName TEXT NOT NULL," +
                "email TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL)");

        // Tabela beleški
        db.execSQL("CREATE TABLE notes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT," +
                "content TEXT," +
                "date TEXT," +
                "userId INTEGER," +
                "FOREIGN KEY(userId) REFERENCES users(id))");

        // Ubacivanje 3 beleške (primeri, userId = 1 jer korisnik još ne postoji, samo za demo)
        db.execSQL("INSERT INTO notes (title, content, date, userId) VALUES " +
                "('Naslov 1', 'Tekst beleške 1', '2025-08-31', 1), " +
                "('Naslov 2', 'Tekst beleške 2', '2025-08-30', 1), " +
                "('Naslov 3', 'Tekst beleške 3', '2025-08-29', 1)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Obrisati i ponovo kreirati
        db.execSQL("DROP TABLE IF EXISTS notes");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    // Ubacivanje korisnika
    public boolean insertUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("fullName", user.getFullName());
        values.put("email", user.getEmail());
        values.put("password", user.getPassword());

        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Provera da li email postoji
    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Login
    public User login(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ? AND password = ?", new String[]{email, password});
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String fullName = cursor.getString(cursor.getColumnIndexOrThrow("fullName"));
            User user = new User(id, fullName, email, password);
            cursor.close();
            return user;
        } else {
            cursor.close();
            return null;
        }
    }

    // Ubacivanje beleške
    public boolean insertNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", note.getTitle());
        values.put("content", note.getContent());
        values.put("date", note.getDate());
        values.put("userId", note.getUserId());

        long result = db.insert("notes", null, values);
        return result != -1;
    }

    // Dohvati sve beleške za korisnika
    public Cursor getNotesForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM notes WHERE userId = ?", new String[]{String.valueOf(userId)});
    }

    // Filtriranje po današnjem datumu
    public Cursor getNotesForUserToday(int userId, String todayDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM notes WHERE userId = ? AND date = ?", new String[]{String.valueOf(userId), todayDate});
    }
    public String getUserFullNameById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String fullName = "";
        Cursor cursor = db.rawQuery("SELECT fullName FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            fullName = cursor.getString(cursor.getColumnIndexOrThrow("fullName"));
        }
        cursor.close();
        return fullName;
    }
    public ArrayList<Note> getNotesForUserList(int userId) {
        ArrayList<Note> notes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM notes WHERE userId = ?", new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                note.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                note.setContent(cursor.getString(cursor.getColumnIndexOrThrow("content")));
                note.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
                note.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow("userId")));
                notes.add(note);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return notes;
    }

    public ArrayList<Note> getNotesForUserTodayList(int userId, String todayDate) {
        ArrayList<Note> notes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM notes WHERE userId = ? AND date = ?", new String[]{String.valueOf(userId), todayDate});

        if (cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                note.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                note.setContent(cursor.getString(cursor.getColumnIndexOrThrow("content")));
                note.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
                note.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow("userId")));
                notes.add(note);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return notes;

}}