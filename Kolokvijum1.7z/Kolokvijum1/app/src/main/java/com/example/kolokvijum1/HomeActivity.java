package com.example.kolokvijum1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import fragments.BeleskeFragment;
import repository.SQLiteHelper;

public class HomeActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefs";
    private static final String KEY_USER_ID = "userId";

    private Toolbar toolbar;
    private TextView tvWelcome;
    private SharedPreferences sharedPreferences;
    private SQLiteHelper dbHelper;

    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvWelcome = findViewById(R.id.tvWelcome);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        dbHelper = new SQLiteHelper(this);

        userId = sharedPreferences.getInt(KEY_USER_ID, -1);

        if (userId != -1) {
            // Dohvati ime i prezime korisnika iz baze
            String fullName = getUserFullName(userId);
            tvWelcome.setText("Dobrodošli nazad, " + fullName + "!");
        } else {
            tvWelcome.setText("Dobrodošli nazad!");
        }
    }

    private String getUserFullName(int userId) {
        // Jednostavna metoda za dohvat imena korisnika iz baze
        return dbHelper.getUserFullNameById(userId);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_notes) {
            // Otvori BeleškeFragment
            openNotesFragment();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openNotesFragment() {
        BeleskeFragment notesFragment = new BeleskeFragment();

        // Prosledi userId fragmentu kroz Bundle
        Bundle bundle = new Bundle();
        bundle.putInt("userId", userId);
        notesFragment.setArguments(bundle);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, notesFragment);
        transaction.commit();
    }
}
