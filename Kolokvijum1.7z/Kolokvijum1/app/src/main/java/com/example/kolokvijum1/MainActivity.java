package com.example.kolokvijum1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import models.User;
import repository.SQLiteHelper;

public class MainActivity extends AppCompatActivity {

    private EditText etFullName, etEmail, etPassword;
    private Button btnRegister;
    private SQLiteHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // inicijalizacija
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);

        dbHelper = new SQLiteHelper(this);

        btnRegister.setOnClickListener(v -> {
            String fullName = etFullName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();

            // Validacija
            if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(MainActivity.this, "Popunite sva polja!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Provera da li je email registrovan
            if (dbHelper.isEmailRegistered(email)) {
                Toast.makeText(MainActivity.this, "Email je već registrovan!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Ubacivanje novog korisnika
            User user = new User(fullName, email, password);
            boolean success = dbHelper.insertUser(user);

            if (success) {
                Toast.makeText(MainActivity.this, "Registracija uspešna!", Toast.LENGTH_SHORT).show();

                // Prelazak na LoginActivity
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // da korisnik ne moze da se vrati na registraciju pritiskom na back
            } else {
                Toast.makeText(MainActivity.this, "Registracija nije uspela, pokušajte ponovo.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
