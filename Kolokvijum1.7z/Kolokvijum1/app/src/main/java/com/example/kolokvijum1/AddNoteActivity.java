package com.example.kolokvijum1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

import models.Note;
import repository.SQLiteHelper;

public class AddNoteActivity extends AppCompatActivity {

    private EditText etTitle, etContent;
    private DatePicker datePicker;
    private Button btnSaveNote;
    private SQLiteHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);
        datePicker = findViewById(R.id.datePicker);
        btnSaveNote = findViewById(R.id.btnSaveNote);
        dbHelper = new SQLiteHelper(this);

        // Uzimanje userId iz SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userId = prefs.getInt("user_id", -1);

        btnSaveNote.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String content = etContent.getText().toString().trim();

            // Datum formatiran kao yyyy-MM-dd
            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth();
            int year = datePicker.getYear();

            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, day);
            String dateStr = String.format("%04d-%02d-%02d", year, month + 1, day);

            if (title.isEmpty() || content.isEmpty()) {
                Toast.makeText(this, "Sva polja su obavezna!", Toast.LENGTH_SHORT).show();
                return;
            }

            Note note = new Note(title, content, dateStr, userId);
            boolean success = dbHelper.insertNote(note);

            if (success) {
                Toast.makeText(this, "Beleška sačuvana!", Toast.LENGTH_SHORT).show();
                finish(); // Zatvori aktivnost i vrati se nazad
            } else {
                Toast.makeText(this, "Greška pri čuvanju!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
