package com.example.kolokvijum2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_IMAGE_CAPTURE = 101;
    private static final int REQUEST_LOCATION_PERMISSION = 102;

    private EditText editText1, editText2;
    private ImageView imageView;
    private CheckBox checkBox;
    private LocationManager locationManager;
    private MediaPlayer mediaPlayer;

    // Retrofit
    public interface JsonPlaceHolderApi {
        @GET("comments")
        Call<List<Comment>> getComments();
    }

    // Model za komentar
    public static class Comment {
        private int postId;
        private int id;
        private String name;
        private String email;
        private String body;

        public String getEmail() {
            return email;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        imageView = findViewById(R.id.imageView);
        checkBox = findViewById(R.id.checkbox);

        // Inicijalizacija LocationManager-a
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Provera i traženje dozvola za lokaciju
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        } else {
            requestLocationUpdates();
        }

        // 3. i 4. - EditText1 logika
        editText1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString();

                // 3. Pokretanje kamere
                if (text.equalsIgnoreCase("kamera")) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                    } else {
                        dispatchTakePictureIntent();
                    }
                }

                // 4. Provera broja karaktera
                if (text.length() == 5) {
                    checkBox.setChecked(true);
                } else if (text.length() > 5) {
                    imageView.setImageResource(R.drawable.default_image); // Default slika
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // 7., 8. i 9. - Checkbox logika
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // 7. Preuzmi email sa Retrofit-om
                    fetchCommentEmail();
                    // 8. Reprodukcija zvuka
                    startSound();
                } else {
                    // 9. Prikaz lokacije kada se odčeka
                    requestLocationUpdates();
                    // 8. Zaustavljanje zvuka
                    stopSound();
                }
            }
        });
    }

    // --- Metodi za Kameru ---
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(imageBitmap); // Prikaz slike
        }
    }

    // --- Metodi za Lokaciju ---
    private void requestLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            } else {
                editText2.setText("Lokacija nije dostupna (omogućite GPS/mrežu)");
            }
        } else {
            editText2.setText("Dozvola za lokaciju nije odobrena.");
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        String lat = String.format("%.4f", location.getLatitude());
        String lon = String.format("%.4f", location.getLongitude());
        editText2.setText("Lat: " + lat + ", Lon: " + lon);
        // Pošto želimo samo početnu lokaciju i kada se odčekira, možemo zaustaviti update
        // locationManager.removeUpdates(this);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        Toast.makeText(this, "Provider " + provider + " omogućen!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Toast.makeText(this, "Provider " + provider + " onemogućen!", Toast.LENGTH_SHORT).show();
    }

    // --- Metodi za Retrofit ---
    private void fetchCommentEmail() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JsonPlaceHolderApi api = retrofit.create(JsonPlaceHolderApi.class);
        Call<List<Comment>> call = api.getComments();

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if (!response.isSuccessful()) {
                    editText2.setText("Code: " + response.code());
                    return;
                }

                List<Comment> comments = response.body();
                if (comments != null && comments.size() >= 3) {
                    String email = comments.get(2).getEmail(); // Treći komentar (indeks 2)
                    editText2.setText(email);
                } else {
                    editText2.setText("Nema dovoljno komentara.");
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                editText2.setText(t.getMessage());
            }
        });
    }

    // --- Metodi za Zvuk ---
    private void startSound() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.sound_file); // Kreiraj sound_file.mp3 u res/raw
            mediaPlayer.setLooping(true); // Ponovi
        }
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    private void stopSound() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopSound(); // Zaustavi zvuk kada se aktivnost uništi
        if (locationManager != null) {
            locationManager.removeUpdates(this); // Prekini praćenje lokacije
        }
    }

    // --- Obrada rezultata dozvola ---
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                Toast.makeText(this, "Dozvola za kameru je odbijena.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestLocationUpdates();
            } else {
                Toast.makeText(this, "Dozvola za lokaciju je odbijena.", Toast.LENGTH_SHORT).show();
                editText2.setText("Dozvola za lokaciju je odbijena.");
            }
        }
    }
}