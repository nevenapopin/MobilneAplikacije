package fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.kolokvijum2.R;

import repository.SQLiteHelper;

public class FirstFragment extends Fragment {

    private Button btnProveri, btnIspisi;
    private SQLiteHelper dbHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        btnProveri = view.findViewById(R.id.btnProveri);
        btnIspisi = view.findViewById(R.id.btnIspisi);

        // Inicijalno: btnProveri je NEAKTIVAN, btnIspisi je AKTIVAN
        btnProveri.setEnabled(false);
        btnIspisi.setEnabled(true);

        dbHelper = new SQLiteHelper(getContext());

        btnProveri.setOnClickListener(v -> {
            // Klik na prvo dugme ako je bilo omogućeno (logika iz zadatka)
            btnProveri.setEnabled(false);
            btnIspisi.setEnabled(true);
        });

        btnIspisi.setOnClickListener(v -> {
            // Klik na drugo dugme ako je bilo omogućeno
            btnIspisi.setEnabled(false);
            btnProveri.setEnabled(true);

            String poslednji = dbHelper.getLastKorisnik();

            if (poslednji != null) {
                // Ako ima entiteta u bazi - prikazi ime poslednjeg korisnika
                showToast("Poslednji korisnik: " + poslednji);
            } else {
                // Ako nema entiteta - uzmi vrednost iz SharedPreferences
                SharedPreferences prefs = requireActivity().getSharedPreferences("KolokvijumPrefs", Context.MODE_PRIVATE);
                String vrednost = prefs.getString("inicijalno", "Nema podatka");

                if (isImeUBazi(vrednost)) {
                    // Ako je ime iz SharedPreferences ime entiteta (postoji u bazi)
                    showToast("Zdravo " + vrednost + "!");
                } else {
                    // Inače samo prikaži vrednost iz SharedPreferences
                    showToast(vrednost);
                }
            }
        });

        return view;
    }

    private void showToast(String msg) {
        Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
    }

    private boolean isImeUBazi(String ime) {
        Cursor cursor = dbHelper.getAllKorisnici();
        if (cursor != null) {
            int imeIndex = cursor.getColumnIndex(SQLiteHelper.COLUMN_IME);
            if (imeIndex == -1) {
                cursor.close();
                return false;
            }
            while (cursor.moveToNext()) {
                String korisnikIme = cursor.getString(imeIndex);
                if (korisnikIme.equalsIgnoreCase(ime)) {
                    cursor.close();
                    return true;
                }
            }
            cursor.close();
        }
        return false;
    }
}
