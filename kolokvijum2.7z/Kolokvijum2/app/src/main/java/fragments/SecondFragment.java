package fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kolokvijum2.R;
import com.example.kolokvijum2.SecondActivity;

import repository.SQLiteHelper;

public class SecondFragment extends Fragment {

    private EditText editIme;
    private Button btnSacuvaj;
    private SQLiteHelper dbHelper;

    private ActivityResultLauncher<String> requestPermissionLauncher;

    private String imeZaUpis = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Launcher za zahtev za dozvolu
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        // Dozvola odobrena → sačuvaj u bazu
                        dbHelper.insertKorisnik(imeZaUpis);
                        Toast.makeText(getContext(), "Ime sačuvano u bazu", Toast.LENGTH_SHORT).show();
                    } else {
                        // Dozvola odbijena → sačuvaj u SharedPreferences i pokreni SecondActivity
                        SharedPreferences prefs = requireActivity().getSharedPreferences("KolokvijumPrefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("inicijalno", imeZaUpis);
                        editor.apply();

                        Intent i = new Intent(getActivity(), SecondActivity.class);
                        startActivity(i);
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        editIme = view.findViewById(R.id.editIme);
        btnSacuvaj = view.findViewById(R.id.btnSacuvaj);
        dbHelper = new SQLiteHelper(getContext());

        btnSacuvaj.setOnClickListener(v -> {
            imeZaUpis = editIme.getText().toString().trim();

            if (imeZaUpis.isEmpty()) {
                Toast.makeText(getContext(), "Unesite ime", Toast.LENGTH_SHORT).show();
                return;
            }

            // Provera dozvole
            if (ContextCompat.checkSelfPermission(
                    requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED) {

                dbHelper.insertKorisnik(imeZaUpis);
                Toast.makeText(getContext(), "Ime sačuvano u bazu", Toast.LENGTH_SHORT).show();

            } else {
                // Nema dozvolu → traži je
                requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        });

        return view;
    }
}