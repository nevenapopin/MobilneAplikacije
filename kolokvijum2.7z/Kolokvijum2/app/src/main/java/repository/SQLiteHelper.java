package repository;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "korisnici.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "korisnik";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_IME = "ime";

    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Kreiraj tabelu
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_IME + " TEXT)";
        db.execSQL(createTable);
    }

    // Ako se verzija baze promeni
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Ubaci novog korisnika
    public void insertKorisnik(String ime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IME, ime);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Vrati poslednje ubačenog korisnika
    public String getLastKorisnik() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " ORDER BY " + COLUMN_ID + " DESC LIMIT 1";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            int indexIme = cursor.getColumnIndex(COLUMN_IME);
            if (indexIme != -1) {
                String ime = cursor.getString(indexIme);
                cursor.close();
                return ime;
            }
        }
        cursor.close();
        return null;
    }

    // Vrati sve korisnike
    public Cursor getAllKorisnici() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}