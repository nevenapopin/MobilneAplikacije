package com.example.kolokvijum2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView tvMessage = findViewById(R.id.textNoPermission);

        String message = getIntent().getStringExtra("message");
        if (message != null) {
            tvMessage.setText(message);
        } else {
            tvMessage.setText("Nema poruke");
        }
    }
}
