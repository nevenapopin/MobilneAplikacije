package com.example.kolokvijum3;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvMessage = findViewById(R.id.textNoPermission);

        String message = getIntent().getStringExtra("message");
        if (message == null || message.isEmpty()) {
            message = "Nema poruke";
        }
        tvMessage.setText(message);
    }
}
